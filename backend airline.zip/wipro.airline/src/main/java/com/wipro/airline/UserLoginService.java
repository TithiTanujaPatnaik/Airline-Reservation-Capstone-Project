package com.wipro.airline;

import java.util.List;

public interface UserLoginService {
	UserLogin createUserLogin(UserLogin userLogin);

	UserLogin updateUserLogin(UserLogin userLogin);

	    List < UserLogin > getAllUserLogin();

	    UserLogin getUserLoginById(long userLoginId);

	    void deleteUserLogin(long id);
}
