package com.wipro.airline;
import java.util.List;
public interface FlightService {
	Flight createFlight(Flight flight);

	Flight updateFlight(Flight flight);

	    List < Flight > getAllFlight();

	    Flight getFlightById(long flightId);

	    void deleteFlight(long id);

}
