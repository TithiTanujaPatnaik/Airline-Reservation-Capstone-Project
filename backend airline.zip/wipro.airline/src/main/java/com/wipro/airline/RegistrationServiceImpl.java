package com.wipro.airline;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service
@Transactional
public class RegistrationServiceImpl implements RegistrationService{
	@Autowired
	private RegistrationRepository registrationRepository;
	
	@Override
	public Registration createRegistration(Registration registration) {
	    return registrationRepository.save(registration);
	}

	//@Override
	//public Registration updateRegistration(Registration registration) {
	  //  Optional < Registration > register= this.registrationRepository.findById(registration.getId());

	  //  if (register.isPresent()) {
	   /// 	Registration registrationUpdate = register.get();
	   /// 	registrationUpdate.setId(registration.getId());
	    //	registrationUpdate.setFirstname(registration.getFirstname());
	    //	registrationUpdate.setLastname(registration.getLastname());
	    //	registrationUpdate.setUsername(registration.getUsername());
	    //	registrationUpdate.setPhone(registration.getPhone());
	    //	registrationUpdate.setEmail(registration.getEmail());
	    //registrationUpdate.setDOB(registration.getDOB());
	    //	registrationUpdate.setPassword(registration.getPassword());
	    	//registrationRepository.save(registrationUpdate);
	      //  return registrationUpdate;
	  //  } else {
	  //      throw new ResourceNotFoundException("Record not found with id : " + registration.getId());
	 //   }
//	}

	@Override
	public List < Registration > getAllRegistration() {
	    return this.registrationRepository.findAll();
	}

	@Override
	public Registration getRegistrationById(String username) {

	    Optional <Registration > register = this.registrationRepository.findById(username);

	    if (register.isPresent()) {
	        return register.get();
	    } 
	    else {
	        throw new ResourceNotFoundException("Record not found with id : " + username);
	    }
	}

	@Override
	public Registration updateRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteRegistration(long id) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	//public void deleteRegistration(long registrationId) {
	  //  Optional < Registration > register = this.registrationRepository.findById(registrationId);

	   // if (register.isPresent()) {
	   //     this.registrationRepository.delete(register.get());
	  //  } else {
	  //      throw new ResourceNotFoundException("Record not found with id : " + registrationId);
	  //  }

	//}

	
		
	}

