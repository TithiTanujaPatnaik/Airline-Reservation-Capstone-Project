package com.wipro.airline;

import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class AirlineController {

	 @PostMapping("/airlines/{id}")
	    public HttpStatus getAirline(@PathVariable long id) {
	       // this.airlineService.deleteAirline(id);
		 System.out.println("id="+id);
	        return HttpStatus.OK;
	    }
	 @GetMapping("/signIn/{username}/{password}")
	    public String  getsignIn(@PathVariable String username,@PathVariable String password) {
	      String Response;
		if(username.equals("tithi")&& password.equals("password") )
	    	  Response="true";
	      else 
	    	  Response="false";
	      System.out.println("id="+password+" "+username);
	        return Response;
	    }
	 @PostMapping("/signIn")
	    public LoginResponse postsignIn(@PathVariable LoginEntity login) {
	       LoginResponse Response=LoginService.getSignInDetails(login);
		 
		 System.out.println("id="+login.getUsername());
	        return Response;
	    }
}
