package com.wipro.airline;

import java.util.List;

public interface ReceiptService {
	Receipt createReceipt(Receipt receipt);

	Receipt updateReceipt(Receipt receipt);

	    List < Receipt > getAllReceipt();

	    Receipt getReceiptById(long receiptId);

	    void deleteReceipt(long id);

}
