package com.wipro.airline;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class RegistrationController {
	@Autowired
    private RegistrationService registrationService;

    @GetMapping("/register")
    public ResponseEntity < List < Registration >> getAllRegistration() {
        return ResponseEntity.ok().body(registrationService.getAllRegistration());
    }

    @GetMapping("/register/{username}")
    public ResponseEntity < Registration > getRegistrationById(@PathVariable String username) {
        return ResponseEntity.ok().body(registrationService.getRegistrationById(username));
    }

    @PostMapping("/register")
    public ResponseEntity < Registration > createRegistration(@RequestBody Registration registration) {
        return ResponseEntity.ok().body(this.registrationService.createRegistration(registration));
    }

   // @PutMapping("/register/{id}")
    //public ResponseEntity < Registration > updateRegistration(@PathVariable long id, @RequestBody Registration registration) {
    	//registration.setId(id);
        //return ResponseEntity.ok().body(this.registrationService.updateRegistration(registration));
    //}

    @DeleteMapping("/register/{id}")
    public HttpStatus deleteRegistration(@PathVariable long id) {
        this.registrationService.deleteRegistration(id);
        return HttpStatus.OK;
    }
}
