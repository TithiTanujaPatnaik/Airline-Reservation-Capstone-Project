package com.wipro.airline;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional
public class SeatServiceImpl implements SeatService{
	@Autowired
	private SeatRepository seatRepository;
	
	@Override
	public Seat createSeat(Seat seat) {
	    return seatRepository.save(seat);
	}

	//@Override
	//public Seat updateSeat(Seat seat) {
	   // Optional < Seat > seatdb= this.seatRepository.findById(seat.getA1());

	   // if (seatdb.isPresent()) {
	    //	Seat seatUpdate = seatdb.get();
	    //	seatUpdate.setA1(seat.getA1());
	    //	seatRepository.save(seatUpdate);
	     //   return seatUpdate;
	    //} else {
	    //    throw new ResourceNotFoundException("Record not found with id : " + seat.getA1());
	    //}
	//}

	@Override
	public List < Seat > getAllSeat() {
	    return this.seatRepository.findAll();
	}

	@Override
	public Seat getSeatById(String id) {

	    Optional <Seat > seatdb = this.seatRepository.findById(id);

	    if (seatdb.isPresent()) {
	        return seatdb.get();
	    } 
	    else {
	        throw new ResourceNotFoundException("Record not found with id : " + id);
	    }
	}

	@Override
	public void deleteSeat(String id) {
	    Optional < Seat > seatdb = this.seatRepository.findById(id);

	    if (seatdb.isPresent()) {
	        this.seatRepository.delete(seatdb.get());
	    } else {
	        throw new ResourceNotFoundException("Record not found with id : " + id);
	    }

	}

	@Override
	public Seat updateSeat(Seat seat) {
		// TODO Auto-generated method stub
		return null;
	}

}
