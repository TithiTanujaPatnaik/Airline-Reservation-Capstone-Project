package com.wipro.airline;
import java.util.List;
public interface SeatService {
	Seat createSeat(Seat seat);

	Seat updateSeat(Seat seat);

	    List < Seat > getAllSeat();

	    Seat getSeatById(String id);

	    void deleteSeat(String id);
}
