package com.wipro.airline;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {


	public static LoginResponse getSignInDetails(LoginEntity login) {
	LoginResponse Response=new LoginResponse();
    if(login.getUsername()=="tithi123" && login.getPassword()=="password" ) {
    	Response.setLoginResponseValue("valid");
    }else {
    	Response.setLoginResponseValue("invalid user");
    }
    
    return Response;
	}

}
