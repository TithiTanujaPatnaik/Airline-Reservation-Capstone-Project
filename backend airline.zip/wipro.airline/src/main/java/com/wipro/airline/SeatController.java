package com.wipro.airline;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class SeatController {
	@Autowired
    private SeatService seatService;

    @GetMapping("/seat")
    public ResponseEntity < List < Seat >> getAllSeat() {
        return ResponseEntity.ok().body(seatService.getAllSeat());
    }

    @GetMapping("/seat/{id}")
    public ResponseEntity < Seat > getSeatById(@PathVariable String id) {
        return ResponseEntity.ok().body(seatService.getSeatById(id));
    }

    @PostMapping("/seat")
    public ResponseEntity < Seat > createSeat(@RequestBody Seat seat) {
        return ResponseEntity.ok().body(this.seatService.createSeat(seat));
    }

    //@PutMapping("/seat/{id}")
  //  public ResponseEntity < Seat > updateSeat(@PathVariable long id, @RequestBody Seat seat) {
   // 	seat.setId(id);
   //     return ResponseEntity.ok().body(this.seatService.updateSeat(seat));
   // }

    @DeleteMapping("/seat/{id}")
    public HttpStatus deleteSeat(@PathVariable String id) {
        this.seatService.deleteSeat(id);
        return HttpStatus.OK;
    }
}
