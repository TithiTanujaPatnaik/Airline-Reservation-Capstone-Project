package com.wipro.airline;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service
@Transactional
public class ReceiptServeImpl implements ReceiptService{
	@Autowired
	private ReceiptRepository receiptRepository;
	
	@Override
	public Receipt createReceipt(Receipt receipt) {
	    return receiptRepository.save(receipt);
	}

	@Override
	public Receipt updateReceipt(Receipt receipt) {
	    Optional < Receipt > receiptdb= this.receiptRepository.findById(receipt.getId());

	    if (receiptdb.isPresent()) {
	    	Receipt receiptUpdate = receiptdb.get();
	    	receiptUpdate.setId(receipt.getId());
	    	receiptUpdate.setFlightname(receipt.getFlightname());
	    	receiptUpdate.setFrom(receipt.getFrom());
	    	receiptUpdate.setTo(receipt.getTo());
	    	receiptUpdate.setDeparture(receipt.getDeparture());
	    	receiptUpdate.setArrival(receipt.getArrival());
	    	receiptUpdate.setSeatnumber(receipt.getSeatnumber());
	    	receiptUpdate.setDate(receipt.getDate());
	    	receiptUpdate.setFare(receipt.getFare());
	    	receiptRepository.save(receiptUpdate);
	        return receiptUpdate;
	    } else {
	        throw new ResourceNotFoundException("Record not found with id : " + receipt.getId());
	    }
	}

	@Override
	public List < Receipt > getAllReceipt() {
	    return this.receiptRepository.findAll();
	}

	@Override
	public Receipt getReceiptById(long receiptId) {

	    Optional <Receipt > receiptdb = this.receiptRepository.findById(receiptId);

	    if (receiptdb.isPresent()) {
	        return receiptdb.get();
	    } 
	    else {
	        throw new ResourceNotFoundException("Record not found with id : " + receiptId);
	    }
	}

	@Override
	public void deleteReceipt(long receiptId) {
	    Optional < Receipt > receiptdb = this.receiptRepository.findById(receiptId);

	    if (receiptdb.isPresent()) {
	        this.receiptRepository.delete(receiptdb.get());
	    } else {
	        throw new ResourceNotFoundException("Record not found with id : " + receiptId);
	    }

	}
}
