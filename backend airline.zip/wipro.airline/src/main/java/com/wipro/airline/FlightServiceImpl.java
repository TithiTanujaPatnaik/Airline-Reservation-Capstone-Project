package com.wipro.airline;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service
@Transactional
public class FlightServiceImpl implements FlightService {
	@Autowired
	private FlightRepository flightRepository;
	
	@Override
	public Flight createFlight(Flight flight) {
	    return flightRepository.save(flight);
	}

	@Override
	public Flight updateFlight(Flight flight) {
	    Optional < Flight > flightdb= this.flightRepository.findById(flight.getId());

	    if (flightdb.isPresent()) {
	    	Flight flightUpdate = flightdb.get();
	    	flightUpdate.setId(flight.getId());
	    	flightUpdate.setFlightname(flight.getFlightname());
	    	flightUpdate.setFrom(flight.getFrom());
	    	flightUpdate.setTo(flight.getTo());
	    	flightUpdate.setDeparture(flight.getDeparture());
	    	flightUpdate.setArrival(flight.getArrival());
	    	flightUpdate.setDuration(flight.getDuration());
	    	flightUpdate.setDate(flight.getDate());
	    	flightUpdate.setFare(flight.getFare());
	    	flightRepository.save(flightUpdate);
	        return flightUpdate;
	    } else {
	        throw new ResourceNotFoundException("Record not found with id : " + flight.getId());
	    }
	}

	@Override
	public List < Flight > getAllFlight() {
	    return this.flightRepository.findAll();
	}

	@Override
	public Flight getFlightById(long flightId) {

	    Optional <Flight > flightdb = this.flightRepository.findById(flightId);

	    if (flightdb.isPresent()) {
	        return flightdb.get();
	    } 
	    else {
	        throw new ResourceNotFoundException("Record not found with id : " + flightId);
	    }
	}

	@Override
	public void deleteFlight(long flightId) {
	    Optional < Flight > flightdb = this.flightRepository.findById(flightId);

	    if (flightdb.isPresent()) {
	        this.flightRepository.delete(flightdb.get());
	    } else {
	        throw new ResourceNotFoundException("Record not found with id : " + flightId);
	    }

	}

}
