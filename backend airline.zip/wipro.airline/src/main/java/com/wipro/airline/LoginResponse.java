package com.wipro.airline;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.index.*;
@Document(collection= "login")
public class LoginResponse {
String LoginResponseValue;

public String getLoginResponseValue() {
	return LoginResponseValue;
}

public void setLoginResponseValue(String loginResponseValue) {
	LoginResponseValue = loginResponseValue;
}
}
