package com.wipro.airline;

import java.util.List;


public interface RegistrationService {
	Registration createRegistration(Registration registration);

	Registration updateRegistration(Registration registration);

	    List < Registration > getAllRegistration();

	    Registration getRegistrationById(String username);

	    void deleteRegistration(long id);

		
}
