import { FormBuilder, FormGroup } from "@angular/forms";

import { ComponentRef } from "@angular/core";
import { LoginPageComponent } from "../login-page/login-page.component";
import { AdminloginComponent } from "./adminlogin.component";
export class LoginForm{
    static loginForm(FormBuilder:FormBuilder,ComponentRef:AdminloginComponent):FormGroup{
        let loginFormGroup:FormGroup=FormBuilder.group({
            username:"",
            password:""
        })
        return loginFormGroup;
    }
}