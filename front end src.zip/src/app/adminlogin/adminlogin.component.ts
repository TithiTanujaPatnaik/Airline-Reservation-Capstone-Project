import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { LoginData } from '../logindata';
import { LoginForm } from './adminlogin.form';
@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  userValid: boolean=true;
  constructor(private router: Router,private loginService:LoginService,private formBuilder:FormBuilder) { 
    this.formBuilder=formBuilder;
    this.loginForm=LoginForm.loginForm(this.formBuilder,this)
  }
  loginForm:FormGroup;

 signin(){
  //this.router.navigate(['/admin']);
  console.log("inside angular signin")
  // let username=document.getElementById('username').value
   //let password=document.getElementById('password')
   let signIn:LoginData=new LoginData();
 
   signIn.username=this.loginForm.get('username')?.value
   signIn.password=this.loginForm.get('password')?.value
   this.loginService.signin(signIn.username,signIn.password).subscribe(Response=>{
     console.log("hiii"+Response)
     if(Response){this.router.navigate(['/admin']);}
    else{this.userValid=false}
    } )}

 login(){
  this.router.navigate(['/login']);
}signup(){
  this.router.navigate(['/signup']);
}
  ngOnInit(): void{
  }

   }
