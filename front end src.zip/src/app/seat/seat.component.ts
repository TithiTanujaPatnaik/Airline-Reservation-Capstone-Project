import { Serializer } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SeatService } from '../seat.service';

@Component({
  selector: 'app-seat',
  templateUrl: './seat.component.html',
  styleUrls: ['./seat.component.css']
})
export class SeatComponent implements OnInit {
seat:any;
  constructor(private seatService:SeatService,private router:Router) { }

  ngOnInit(): void {
    this.getSeat();
  }
private getSeat(){
  this.seatService.getSeatList().subscribe(data=>{this.seat=data});
}
seatDetails(id:number){this.router.navigate(['seatprogram',id]);}
}
