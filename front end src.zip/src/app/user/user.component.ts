import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SignUpService } from '../sign-up.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  signup:any;
  
  constructor(private signupService: SignUpService,private router:Router) { }


  ngOnInit(): void { this.getAirlines();
  }
  private getAirlines(){
    this.signupService.getAirlineList().subscribe(data=>{this.signup=data});
  }
airlineDetails(id:number){this.router.navigate(['profile',id]);}
updateAirline(id:number){this.router.navigate(['signup',id]);}
deleteAirline(id:number){this.signupService.deleteAirline(id).subscribe(data=>{console.log(data);
this.getAirlines();})}

}
