import { Injectable, OnInit } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { Observable,observable } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { LoginData } from './logindata';
import { SignUp } from './sign-up';
import { UserComponent } from './user/user.component';
import { User } from './user';
import { ImplicitReceiver } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class SignUpService  {

private baseURL='http://localhost:8080/register'
  constructor(private http:HttpClient) { }
 
  getAirlineList():Observable<SignUp[]>{
    return this.http.get<SignUp[]>(`${this.baseURL}`);
  }
  getAirlineById(user:User,username: string):Observable<SignUp>{
  const id= user.username;
    return this.http.get<SignUp>(`${this.baseURL}/${id}`);
  }
  updateAirline(id:number,signup:SignUp):Observable<object>{
    return this.http.put(`${this.baseURL}/${id}`,signup);
  }
  createAirline(signup:SignUp):Observable<object>{
    return this.http.post(`${this.baseURL}`,signup);
  }
 
  deleteAirline(id:number):Observable<any>{
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  AirlineList(){
    return this.http.get('http://localhost:8080/airlines')
  }

  checkout(){
    return this.http.get('http://localhost:4200/checkout')
  }
  login(){
    return this.http.get('http://localhost:4200/login')
  }
  signin(login:LoginData){
    console.log("inside signUpService")
    let url='http://localhost:4200/profile';
    return this.http.post(url,login)

  }
  signup()
{
  return this.http.get('http://localhost:4200/signup')
}
adminlogin(){
  return this.http.get('http://localhost:4200/adminlogin')
}

}
