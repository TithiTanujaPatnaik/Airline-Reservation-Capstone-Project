import { registerLocaleData } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SignUp } from '../sign-up';
import { SignUpService } from '../sign-up.service';
import { SignUpComponent } from '../sign-up/sign-up.component';
import { User } from '../user';
import { UserComponent } from '../user/user.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
user:User = new User();
userdb:SignUp=new SignUp();
 

  constructor(private signupService:SignUpService,private router:Router) { }

  ngOnInit(): void {
  }
userLogin(){
  console.log(this.user)
  this.signupService.getAirlineById(this.user,this.userdb.username).subscribe(data=>{
    this.userdb =data;
    if(this.user.password === this.userdb.password){
    this.router.navigate(['/select']);
    }
    else{alert("wrong password")}

  },error=>{
    alert("id not found")});
}
adminlogin(){
  this.router.navigate(['/adminlogin'])
}
  signup(){
    this.router.navigate(['/signup']);
  }
  
}
