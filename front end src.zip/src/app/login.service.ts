import { Injectable } from '@angular/core';
import { LoginData, LoginResponse } from './logindata';
import{HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
private url='http://localhost:8080/signIn';
  constructor(private http:HttpClient) { }
  signin(username:string,password:string):Observable<any>{
    console.log("inside signUpService")
    
    return this.http.get<any>(`${this.url}/${username}/${password}`);

  }
  userLogin(loginData:LoginData):Observable<LoginResponse>{
    return this.http.post<LoginResponse>(`${this.url}`,loginData)
  }
}
