import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Seat } from '../seat';
import { SeatService } from '../seat.service';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.css']
})
export class ReceiptComponent implements OnInit {
 // booking:Bookings=BookingService.booking
//user:Customer|any;
seat:any;
flight:any;
  constructor(private seatService:SeatService,private flightService:FlightService,private router:Router) { } //private customerservice:CustomerService

  ngOnInit(): void { //this.customerservice.getCustomerDetails().subscribe(data=>{
    ///console.log(data);
   // this.user=data;
 // });
 this.getSeat();
 this.getFlight();
  }
private getSeat(){
  this.seatService.getSeatList().subscribe(data=>{this.seat=data});
}
private getFlight(){
  this.flightService.getFlightList().subscribe(data=>{this.flight=data});
}
seatDetails(A1:number){this.router.navigate(['receipt',A1]);}
flightDetails(id:number){this.router.navigate(['receipt',id]);}
deleteSeat(A1:number){this.seatService.deleteSeat(A1).subscribe(data=>{console.log(data);
this.getSeat();})}
}
