import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { UserComponent } from './user/user.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AdminComponent } from './admin/admin.component';
import { DeleteComponent } from './delete/delete.component';
import { FlightsearchComponent } from './flightsearch/flightsearch.component';
import { SeatSelectComponent } from './seat-select/seat-select.component';

import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { PaymentComponent } from './payment/payment.component';
import { FlightSelectComponent } from './flight-select/flight-select.component';
import{NgChartsModule} from 'ng2-charts';
import { CheckoutComponent } from './checkout/checkout.component';
import { ProfileComponent } from './profile/profile.component';
import { ContactUsComponent } from './contact-us/contact-us.component';

import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FlightComponent } from './flight/flight.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { LoginComponent } from './login/login.component';
import { SeatComponent } from './seat/seat.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    UserComponent,
    SignUpComponent,
    AdminComponent,
    DeleteComponent,
    FlightsearchComponent,
    SeatSelectComponent,
    ForgotpasswordComponent,
    ResetpasswordComponent,
    PaymentComponent,
    FlightSelectComponent,
    ContactUsComponent,
    
  
   
    CheckoutComponent,
        ProfileComponent,
        AdminloginComponent,
        FlightComponent,
        ReceiptComponent,
        LoginComponent,
        SeatComponent,
       
      
       
      
   

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    NgChartsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    BrowserAnimationsModule,
   HttpClientModule,
    ReactiveFormsModule,
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
