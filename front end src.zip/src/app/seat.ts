export class Seat {
    id!:string;
   position!:string;
   price!:number;
}
