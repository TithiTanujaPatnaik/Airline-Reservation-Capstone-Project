import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flight-select',
  templateUrl: './flight-select.component.html',
  styleUrls: ['./flight-select.component.css']
})
export class FlightSelectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
