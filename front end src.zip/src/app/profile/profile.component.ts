import { Component, OnInit } from '@angular/core';
import { SignUpService } from '../sign-up.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  signup:any;
  
  constructor(private signupService:SignUpService,private router:Router) { }
 
  ngOnInit(): void {
  }
  airlineDetails(id:number){this.router.navigate(['profile',id]);}
}
