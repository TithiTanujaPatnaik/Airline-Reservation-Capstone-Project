import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import {Router} from '@angular/router';

import { LoginForm } from './login-page.form';
import { LoginService } from '../login.service';
import { LoginData } from '../logindata';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {//AfterViewInit{
  userValid:boolean=true;
  constructor(private router: Router,private loginService:LoginService,private formBuilder:FormBuilder) {
    this.formBuilder=formBuilder;
    this.loginForm=LoginForm.loginForm(this.formBuilder,this);
   }
   loginForm:FormGroup;
 
  // ngAfterViewInit(){
    signin(){
      console.log("inside angular signin")
     // let username=document.getElementById('username').value
      //let password=document.getElementById('password').value
      
      
      let signIn:LoginData=new LoginData();
    
      signIn.username=this.loginForm.get('username')?.value
      signIn.password=this.loginForm.get('password')?.value
      this.loginService.signin(signIn.username,signIn.password).subscribe(Response=>{
        console.log("hiii"+Response)
        if(Response){this.router.navigate(['/user']);}
       else{this.userValid=false}
      })
     }
  // }
//username!:string;
//password!:string;

adminlogin(){
  this.router.navigate(['/adminlogin'])
}
  signup(){
    this.router.navigate(['/signup']);
  }
  
 
  ngOnInit(): void {
  }
}
