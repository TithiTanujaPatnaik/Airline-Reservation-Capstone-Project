import { FormBuilder, FormGroup } from "@angular/forms";
import { LoginPageComponent } from "./login-page.component";
import { ComponentRef } from "@angular/core";
export class LoginForm{
    static loginForm(FormBuilder:FormBuilder,ComponentRef:LoginPageComponent):FormGroup{
        let loginFormGroup:FormGroup=FormBuilder.group({
            username:"",
            password:""
        })
        return loginFormGroup;
    }
}