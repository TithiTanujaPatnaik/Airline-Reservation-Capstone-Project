import { Seat } from './seat';

describe('Seat', () => {
  it('should create an instance', () => {
    expect(new Seat()).toBeTruthy();
  });
});
