import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Seat } from '../seat';
import { SeatService } from '../seat.service';
import { FormArray, FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { FormGroup,FormControl,Validators } from '@angular/forms';
@Component({
  selector: 'app-seat-select',
  templateUrl: './seat-select.component.html',
  styleUrls: ['./seat-select.component.css']
})
export class SeatSelectComponent implements OnInit {
seat:Seat = new Seat();
//flight:any;
//form:FormGroup;
//data: Array<any>=[
  //{name:'1A',value:'A1'}

//] ;
 
  constructor(private fb:FormBuilder,private seatService:SeatService,private router:Router,private flightService:FlightService) { 
   // this.form=this.fb.group({checkArray:this.fb.array([],[Validators.required])})
  }
//onCheckboxChange(e:any){
 // const checkArray:FormArray=this.form.get('checkArray') as FormArray;
 // if(e.target.checked){
 //   checkArray.push(new FormControl(e.target.value));
 // } else {
 //   let i: number = 0;
  //  checkArray.controls.forEach((item: any)=> {
  //    if (item.value == e.target.value) {
    //    checkArray.removeAt(i);
     //   return;
   //   }
    //  i++;
  //  });
 // }  }



  saveSeat(){
  this.seatService.createSeat(this.seat).subscribe(data=>{console.log(data);
  this.goToSeatList();},error=>console.log(error));
}
goToSeatList(){
  this.router.navigate(['/payment']);
}

onSubmit(){
 console.log(this.seat);
  this.saveSeat();
this.router.navigate(['/payment']);}
   



  ngOnInit(): void {
    //this.getFlight();
  }
 // private getFlight(){
  //  this.flightService.getFlightList().subscribe(data=>{this.flight=data});
  //}
 // flightDetails(id:number){this.router.navigate(['/payment',id]);}
}
function ngOnInit() {
  throw new Error('Function not implemented.');
}

