import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { LoginPageComponent } from './login-page/login-page.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminComponent } from './admin/admin.component';
import { DeleteComponent } from './delete/delete.component';
import { SeatSelectComponent } from './seat-select/seat-select.component';
import { FlightsearchComponent } from './flightsearch/flightsearch.component';
import { PaymentComponent } from './payment/payment.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ProfileComponent } from './profile/profile.component';
import { FlightSelectComponent } from './flight-select/flight-select.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FlightComponent } from './flight/flight.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { LoginComponent } from './login/login.component';
import { SeatComponent } from './seat/seat.component';



const routes: Routes = [
  { path: 'user', component: UserComponent },
  { path: 'login',component: LoginComponent },
  {path : 'signup', component : SignUpComponent},
  {path:'admin',component:AdminComponent},
  {path:'delete',component:DeleteComponent},
  {path:'seat',component:SeatSelectComponent},
  {path:'flight',component:FlightsearchComponent},
  {path:'',redirectTo:'/flight',pathMatch:'full'},
  {path:'payment',component:PaymentComponent},
  {path:'reset',component:ResetpasswordComponent},
  {path:'forgot',component:ForgotpasswordComponent},
  {path:'checkout',component:CheckoutComponent},
{path:'adminlogin',component:AdminloginComponent},
{path:'profile',component:ProfileComponent},
{path:'select',component:FlightSelectComponent},
{path:'contact',component:ContactUsComponent},
{path:'flightdetails',component:FlightComponent},
{path:'receipt',component:ReceiptComponent},
{path:'seatprogram',component:SeatComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []

})
export class AppRoutingModule { }
