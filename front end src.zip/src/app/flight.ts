import { Time } from "@angular/common";

export class Flight {
    id!:number;
    flightname!:string;
    from!:string;
    to!:string;
    departure!:number;
    arrival!:number;
    duration!:string;
    date!:string;
    fare!:number;
    
}
