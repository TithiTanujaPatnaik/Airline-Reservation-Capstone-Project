export class SignUp {
  
    username!:string;
    firstname!:string;
    lastname!:string;
    email!:string;
    password!:string;
    phone!:string;
    dob!:string;
}
