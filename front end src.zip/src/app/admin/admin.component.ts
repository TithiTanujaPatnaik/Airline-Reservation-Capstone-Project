import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConnectableObservable } from 'rxjs';
import { Flight } from '../flight';
import { FlightService } from '../flight.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

flight:Flight=new Flight();
  constructor(private flightService:FlightService,private router:Router) { }
saveFlight(){
  this.flightService.createFlight(this.flight).subscribe(data=>{console.log(data);
    this.goToFlightList();},error=>console.log(error));
    
  }
  goToFlightList(){
    this.router.navigate(['/flightdetails']);
  }
  onSubmit(){
    console.log(this.flight);
    this.saveFlight();
  }

  ngOnInit(): void {
    
  }
  

}
