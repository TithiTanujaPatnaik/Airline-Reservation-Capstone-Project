export class LoginData {
    id!:number;
    username!:string;
    password!:string;
}
export class LoginResponse{
    LoginResponseValue!:string;
}
