import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { SignUp } from '../sign-up';
import { SignUpService } from '../sign-up.service';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
signup:SignUp =new SignUp();
  constructor(private signupService:SignUpService,private router: Router) { }
saveAirline(){
  this.signupService.createAirline(this.signup).subscribe(data=>{console.log(data);
      this.goToAirlineList();},error=>console.log(error));
}
goToAirlineList(){
  this.router.navigate(['/flightdetails']);
}
onSubmit(){
  console.log(this.signup);
  this.saveAirline();
}
  ngOnInit(): void {
   
  }
  

}
