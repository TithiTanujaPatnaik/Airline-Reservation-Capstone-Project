export class User {
  
  password!:string;
  username!:string;
 
}
