import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Seat } from './seat';

@Injectable({
  providedIn: 'root'
})
export class SeatService {
private baseURL="http://localhost:8080/seat";

  constructor(private http:HttpClient) { }
  getSeatList():Observable<Seat[]>{
    return this.http.get<Seat[]>(`${this.baseURL}`);
  }
  getSeatById(id:number):Observable<Seat>{
   
    return this.http.get<Seat>(`${this.baseURL}`);
  }
deleteSeat(id:number):Observable<Object>{
  return this.http.delete(`${this.baseURL}/${id}`);
}
createSeat(seat:Seat):Observable<Object>{
  return this.http.post(`${this.baseURL}`,seat);
}
}
