import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';
import { Flight } from '../flight';
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
 
flight:any;
  constructor(private flightService:FlightService,private router:Router) { }

  ngOnInit(): void {
    this.getFlight();
  }
  onSubmit(){
    console.log(this.flight);
    this.deleteFlight(this.flight.id);
  }
  private getFlight(){
    this.flightService.getFlightList().subscribe(data=>{this.flight=data});
  }
deleteFlight(id:number){this.flightService.deleteFlight(id).subscribe(data=>{console.log(data);
this.getFlight();}) }}//;this.router.navigate(['flightdetails',id]);}}

