import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-flightsearch',
  templateUrl: './flightsearch.component.html',
  styleUrls: ['./flightsearch.component.css']
})
export class FlightsearchComponent implements OnInit {

  constructor(private router: Router) { }
  signup(){
    this.router.navigate(['/signup']);
  }
  login(){
    this.router.navigate(['/login']);
  }
  ngOnInit(): void {
  }

}
