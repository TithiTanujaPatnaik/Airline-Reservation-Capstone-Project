import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Flight } from './flight';

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private baseURL='http://localhost:8080/flight';
  constructor(private http:HttpClient) { }
  getFlightList():Observable<Flight[]>{
    return this.http.get<Flight[]>(`${this.baseURL}`);
  }
  getFlightById(id:number):Observable<Flight>{
    return this.http.get<Flight>(`${this.baseURL}`);
  }
  updateFlight(id:number,flight:Flight):Observable<Object>{
    return this.http.put(`${this.baseURL}/${id}`,flight);
  }
  deleteFlight(id:number):Observable<Object>{
    return this.http.delete(`${this.baseURL}/${id}`);
  }
  createFlight(flight:Flight):Observable<Object>{
    return this.http.post(`${this.baseURL}`,flight);
  }
}
