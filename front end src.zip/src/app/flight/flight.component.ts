import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightService } from '../flight.service';

@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrls: ['./flight.component.css']
})
export class FlightComponent implements OnInit {
flight:any;
  constructor(private flightService:FlightService,private router:Router) { }

  ngOnInit(): void {
    this.getFlight();
  }
private getFlight(){
  this.flightService.getFlightList().subscribe(data=>{this.flight=data});
}
flightDetails(id:number){this.router.navigate(['flightdetails',id]);}

updateAirline(id:number){this.router.navigate(['admin',id]);}
deleteAirline(id:number){this.flightService.deleteFlight(id).subscribe(data=>{console.log(data);
this.getFlight();})}
}
